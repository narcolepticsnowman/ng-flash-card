angular.module("ngFlashCard",[]);
angular('ngFlashCard').directive("flashCards",[function () {
    return {
        scope:{
             cardGroups: "="
        },
        controller: "flashCardsController",
        template: "<div>Yo dawg, these some flash cards and shizzle</div>"
    };
}]);
angular.module('ngFlashCards').controller("flashCardsController",[function(){

}]);